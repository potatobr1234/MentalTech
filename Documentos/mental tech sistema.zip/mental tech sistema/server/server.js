// Mental Tech — servidor do sistema de login e cadastro.
// Serve o site estático (pasta "Mental tech html") e expõe as rotas de
// autenticação em /api/auth/*, gravando os usuários em SQLite.

try {
  require('dotenv').config();
} catch (err) {
  if (err.code === 'MODULE_NOT_FOUND') {
    console.error(
      '\n✖ Dependências não instaladas. Rode "npm install" dentro da pasta server/,\n' +
      '  ou use o iniciar.bat / iniciar.command na raiz do projeto, que instalam sozinhos.\n'
    );
    process.exit(1);
  }
  throw err;
}

const path = require('path');
const express = require('express');
const session = require('express-session');
const SQLiteStore = require('better-sqlite3-session-store')(session);
const db = require('./db/database');
const authRoutes = require('./routes/auth');
const consultasRoutes = require('./routes/consultas');
const psicologoRoutes = require('./routes/psicologo');
const { USER_PAGES, PROFESSIONAL_PAGES } = require('./config/protectedPages');

const app = express();

const PORT = process.env.PORT || 3000;
const FRONTEND_DIR = path.join(__dirname, '..', 'Mental tech html');
const isProd = process.env.NODE_ENV === 'production';

if (!process.env.SESSION_SECRET) {
  console.warn(
    '[aviso] SESSION_SECRET não definido no .env — usando um valor de desenvolvimento. ' +
    'Defina SESSION_SECRET antes de usar isso em produção.'
  );
}

app.use(express.urlencoded({ extended: false })); // formulários HTML (application/x-www-form-urlencoded)
app.use(express.json()); // suporte opcional a clientes que preferirem enviar JSON

app.use(
  session({
    store: new SQLiteStore({ client: db, expired: { clear: true, intervalMs: 15 * 60 * 1000 } }),
    name: 'mt.sid',
    secret: process.env.SESSION_SECRET || 'dev-only-secret-troque-isso',
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      sameSite: 'lax',
      secure: isProd, // exige HTTPS em produção
      maxAge: 1000 * 60 * 60 * 24 * 7, // 7 dias
    },
  })
);

// Rotas de login/cadastro/logout
app.use('/api/auth', authRoutes);

// Sistema de marcar consultas (busca de psicólogos, horários, agendamento)
// e painel do profissional (dashboard, pacientes, disponibilidade).
// Ambas exigem sessão válida — cada rota checa o tipo de conta internamente.
app.use('/api', consultasRoutes);
app.use('/api/psicologo', psicologoRoutes);

// Exige login com o tipo de conta certo antes de servir cada área do site:
// USER_PAGES é do "jovem", PROFESSIONAL_PAGES é do psicólogo.
app.use((req, res, next) => {
  const isUserPage = USER_PAGES.includes(req.path);
  const isProfessionalPage = PROFESSIONAL_PAGES.includes(req.path);
  if (!isUserPage && !isProfessionalPage) return next();

  const account = req.session.account;
  if (isUserPage && account && account.type === 'user') return next();
  if (isProfessionalPage && account && account.type === 'professional') return next();

  const message = 'Faça login para continuar.';
  const loginPage = isProfessionalPage ? '/login-profissional.html' : '/login.html';
  const query = new URLSearchParams({ error: message, redirect: req.path }).toString();
  return res.redirect(`${loginPage}?${query}`);
});

// Site estático (HTML/CSS/JS já existentes)
app.use(express.static(FRONTEND_DIR));

app.get('/', (req, res) => {
  res.sendFile(path.join(FRONTEND_DIR, 'index.html'));
});

// 404 simples para o restante
app.use((req, res) => {
  res.status(404).sendFile(path.join(FRONTEND_DIR, 'index.html'));
});

const server = app.listen(PORT, () => {
  console.log(`Mental Tech rodando em http://localhost:${PORT}`);
});

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(
      `\n✖ A porta ${PORT} já está em uso (provavelmente o servidor já está rodando em outra janela).\n` +
      `  Feche a outra janela ou mude PORT em server/.env.\n`
    );
    process.exit(1);
  }
  throw err;
});
