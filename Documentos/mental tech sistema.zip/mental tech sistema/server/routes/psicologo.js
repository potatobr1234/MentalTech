// Rotas exclusivas do painel do profissional (psicólogo).
//   GET /api/psicologo/dashboard        <- painel-psicologo.html
//   GET /api/psicologo/pacientes        <- pacientes.html
//   GET /api/psicologo/disponibilidade  <- disponibilidade.html
//   PUT /api/psicologo/disponibilidade  <- disponibilidade.html (salvar)

const express = require('express');
const db = require('../db/database');

const router = express.Router();

function requireProfessional(req, res, next) {
  if (req.session.account && req.session.account.type === 'professional') return next();
  return res.status(401).json({ ok: false, error: 'Faça login para continuar.' });
}

router.use(requireProfessional);

// ---------------------------------------------------------------------------
// GET /api/psicologo/dashboard
// ---------------------------------------------------------------------------
router.get('/dashboard', (req, res) => {
  const professionalId = req.session.account.id;
  const today = new Date().toISOString().slice(0, 10);

  const todayCount = db
    .prepare(`SELECT COUNT(*) AS n FROM consultations WHERE professional_id = ? AND date = ? AND status != 'cancelada'`)
    .get(professionalId, today).n;

  const now = new Date();
  const nowTime = now.toTimeString().slice(0, 5);
  const next = db
    .prepare(
      `SELECT c.date, c.time, u.full_name AS patient_name
       FROM consultations c JOIN users u ON u.id = c.user_id
       WHERE c.professional_id = ? AND c.status != 'cancelada'
         AND (c.date > ? OR (c.date = ? AND c.time >= ?))
       ORDER BY c.date ASC, c.time ASC LIMIT 1`
    )
    .get(professionalId, today, today, nowTime);

  const patientsTotal = db
    .prepare(`SELECT COUNT(DISTINCT user_id) AS n FROM consultations WHERE professional_id = ?`)
    .get(professionalId).n;

  const upcoming = db
    .prepare(
      `SELECT c.id, c.date, c.time, c.status, u.full_name AS patient_name
       FROM consultations c JOIN users u ON u.id = c.user_id
       WHERE c.professional_id = ? AND c.status != 'cancelada'
         AND (c.date > ? OR (c.date = ? AND c.time >= ?))
       ORDER BY c.date ASC, c.time ASC LIMIT 5`
    )
    .all(professionalId, today, today, nowTime);

  const recentActivity = db
    .prepare(
      `SELECT c.created_at, c.status, c.date, c.time, u.full_name AS patient_name
       FROM consultations c JOIN users u ON u.id = c.user_id
       WHERE c.professional_id = ?
       ORDER BY c.created_at DESC LIMIT 6`
    )
    .all(professionalId);

  res.json({
    ok: true,
    // TODO (backend): unread_messages depende do futuro sistema de mensagens/chat.
    unread_messages: 0,
    today_count: todayCount,
    next_appointment: next || null,
    patients_total: patientsTotal,
    upcoming,
    recent_activity: recentActivity,
  });
});

// ---------------------------------------------------------------------------
// GET /api/psicologo/pacientes
// ---------------------------------------------------------------------------
router.get('/pacientes', (req, res) => {
  const professionalId = req.session.account.id;
  const today = new Date().toISOString().slice(0, 10);

  const rows = db
    .prepare(
      `SELECT u.id, u.full_name,
              MAX(c.created_at) AS last_interaction,
              MIN(CASE WHEN c.date >= ? AND c.status != 'cancelada' THEN c.date || ' ' || c.time END) AS next_appointment
       FROM consultations c JOIN users u ON u.id = c.user_id
       WHERE c.professional_id = ?
       GROUP BY u.id
       ORDER BY u.full_name`
    )
    .all(today, professionalId);

  res.json({ ok: true, pacientes: rows });
});

// ---------------------------------------------------------------------------
// GET /api/psicologo/disponibilidade
// ---------------------------------------------------------------------------
router.get('/disponibilidade', (req, res) => {
  const professionalId = req.session.account.id;
  const slots = db
    .prepare(`SELECT id, weekday, start_time, end_time FROM availability_slots WHERE professional_id = ? ORDER BY weekday, start_time`)
    .all(professionalId);
  const exceptions = db
    .prepare(`SELECT id, date, reason FROM availability_exceptions WHERE professional_id = ? ORDER BY date`)
    .all(professionalId);
  res.json({ ok: true, slots, exceptions });
});

// ---------------------------------------------------------------------------
// PUT /api/psicologo/disponibilidade — substitui os horários semanais e
// exceções do profissional pelo conjunto enviado.
// body: { slots: [{weekday, start_time, end_time}], exceptions: [{date, reason}] }
// ---------------------------------------------------------------------------
router.put('/disponibilidade', (req, res) => {
  const professionalId = req.session.account.id;
  const slots = Array.isArray(req.body.slots) ? req.body.slots : [];
  const exceptions = Array.isArray(req.body.exceptions) ? req.body.exceptions : [];

  const timeRe = /^\d{2}:\d{2}$/;
  for (const s of slots) {
    if (
      typeof s.weekday !== 'number' || s.weekday < 0 || s.weekday > 6 ||
      !timeRe.test(s.start_time) || !timeRe.test(s.end_time) || s.start_time >= s.end_time
    ) {
      return res.status(400).json({ ok: false, error: 'Horário semanal inválido.' });
    }
  }
  for (const e of exceptions) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(e.date)) {
      return res.status(400).json({ ok: false, error: 'Data de exceção inválida.' });
    }
  }

  const replaceAll = db.transaction(() => {
    db.prepare('DELETE FROM availability_slots WHERE professional_id = ?').run(professionalId);
    db.prepare('DELETE FROM availability_exceptions WHERE professional_id = ?').run(professionalId);

    const insertSlot = db.prepare(
      'INSERT INTO availability_slots (professional_id, weekday, start_time, end_time) VALUES (?, ?, ?, ?)'
    );
    slots.forEach((s) => insertSlot.run(professionalId, s.weekday, s.start_time, s.end_time));

    const insertException = db.prepare(
      'INSERT INTO availability_exceptions (professional_id, date, reason) VALUES (?, ?, ?)'
    );
    exceptions.forEach((e) => insertException.run(professionalId, e.date, e.reason || null));
  });

  replaceAll();
  res.json({ ok: true });
});

module.exports = router;
