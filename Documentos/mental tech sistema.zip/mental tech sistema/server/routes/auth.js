// Rotas do sistema de login e cadastro.
// Casam exatamente com os <form action="..."> já existentes no frontend:
//   POST /api/auth/register                 <- cadastro.html
//   POST /api/auth/login                    <- login.html
//   POST /api/auth/professional/register    <- cadastro-profissional.html
//   POST /api/auth/professional/login       <- login-profissional.html
//   GET  /api/auth/logout                   <- links "Sair" do painel logado
//   GET  /api/auth/me                       <- checagem de sessão (uso futuro)
//   POST /api/auth/password/esqueci         <- recuperar-senha.html
//   POST /api/auth/password/redefinir       <- redefinir-senha.html

const crypto = require('crypto');
const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../db/database');
const {
  validateRegisterUser,
  validateRegisterProfessional,
  validateLogin,
  validateForgotPassword,
  validateResetPassword,
} = require('../utils/validators');
const { ALL: PROTECTED_PAGES } = require('../config/protectedPages');

const router = express.Router();
const SALT_ROUNDS = 12;
const RESET_TOKEN_TTL_MINUTES = 30;

// O front-end envia formulários HTML tradicionais (application/x-www-form-urlencoded),
// então por padrão respondemos com redirects (302) carregando ?error= ou ?registered=1
// na URL, que o js/auth-messages.js lê e exibe. Se a requisição pedir JSON
// explicitamente (Accept: application/json — ex.: um cliente mobile/fetch),
// respondemos com JSON em vez de redirecionar.
function wantsJson(req) {
  return req.get('accept') && req.get('accept').includes('application/json');
}

function fail(req, res, redirectTo, message, status = 400) {
  if (wantsJson(req)) {
    return res.status(status).json({ ok: false, error: message });
  }
  return res.redirect(`${redirectTo}?error=${encodeURIComponent(message)}`);
}

function succeed(req, res, redirectTo, payload = {}) {
  if (wantsJson(req)) {
    return res.status(200).json({ ok: true, ...payload });
  }
  return res.redirect(redirectTo);
}

// ---------------------------------------------------------------------------
// POST /api/auth/register — cadastro de usuário (jovem)
// ---------------------------------------------------------------------------
router.post('/register', (req, res) => {
  const error = validateRegisterUser(req.body);
  if (error) return fail(req, res, '/cadastro.html', error);

  const { full_name, email, birth_date, password } = req.body;
  const normalizedEmail = email.trim().toLowerCase();

  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(normalizedEmail);
  if (existing) return fail(req, res, '/cadastro.html', 'Já existe uma conta com este e-mail.');

  const password_hash = bcrypt.hashSync(password, SALT_ROUNDS);

  const insert = db.prepare(`
    INSERT INTO users (full_name, email, birth_date, password_hash, terms_accepted_at)
    VALUES (@full_name, @email, @birth_date, @password_hash, datetime('now'))
  `);

  insert.run({
    full_name: full_name.trim(),
    email: normalizedEmail,
    birth_date,
    password_hash,
  });

  return succeed(req, res, '/login.html?registered=1');
});

// ---------------------------------------------------------------------------
// POST /api/auth/login — login de usuário (jovem)
// ---------------------------------------------------------------------------
router.post('/login', (req, res) => {
  const error = validateLogin(req.body);
  if (error) return fail(req, res, '/login.html', error);

  const { email, password } = req.body;
  const normalizedEmail = email.trim().toLowerCase();

  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(normalizedEmail);
  const passwordOk = user && bcrypt.compareSync(password, user.password_hash);

  if (!passwordOk) {
    return fail(req, res, '/login.html', 'E-mail ou senha inválidos.', 401);
  }

  req.session.regenerate((err) => {
    if (err) return fail(req, res, '/login.html', 'Não foi possível iniciar a sessão. Tente novamente.', 500);

    req.session.account = {
      type: 'user',
      id: user.id,
      full_name: user.full_name,
      email: user.email,
    };

    // Depois de um redirecionamento forçado pelo guard de login (ex: o
    // usuário tentou abrir /psicologos.html sem estar logado), volta para
    // a página original em vez de mandar sempre para o dashboard.
    // Só aceitamos alvos da whitelist PROTECTED_PAGES para evitar open redirect.
    const requestedRedirect = req.body.redirect;
    const target = PROTECTED_PAGES.includes(requestedRedirect) ? requestedRedirect : '/dashboard.html';

    return succeed(req, res, target, { account: req.session.account });
  });
});

// ---------------------------------------------------------------------------
// POST /api/auth/professional/register — cadastro profissional
// ---------------------------------------------------------------------------
router.post('/professional/register', (req, res) => {
  const error = validateRegisterProfessional(req.body);
  if (error) return fail(req, res, '/cadastro-profissional.html', error);

  const { full_name, email, crp_number, specialty, password } = req.body;
  const normalizedEmail = email.trim().toLowerCase();
  const normalizedCrp = crp_number.trim().toUpperCase();

  const existingEmail = db.prepare('SELECT id FROM professionals WHERE email = ?').get(normalizedEmail);
  if (existingEmail) return fail(req, res, '/cadastro-profissional.html', 'Já existe uma conta com este e-mail.');

  const existingCrp = db.prepare('SELECT id FROM professionals WHERE crp_number = ?').get(normalizedCrp);
  if (existingCrp) return fail(req, res, '/cadastro-profissional.html', 'Este CRP já está cadastrado.');

  const password_hash = bcrypt.hashSync(password, SALT_ROUNDS);

  // TODO (integração futura): antes de marcar como "approved", validar o
  // CRP contra o registro do Conselho Federal de Psicologia. Por ora toda
  // conta nova entra como "pending" e o login de profissionais bloqueia
  // o acesso até a aprovação manual (ver PATCH sugerido em professionals.verification_status).
  const insert = db.prepare(`
    INSERT INTO professionals (full_name, email, crp_number, specialty, password_hash, verification_status)
    VALUES (@full_name, @email, @crp_number, @specialty, @password_hash, 'pending')
  `);

  insert.run({
    full_name: full_name.trim(),
    email: normalizedEmail,
    crp_number: normalizedCrp,
    specialty,
    password_hash,
  });

  return succeed(req, res, '/login-profissional.html?pending=1');
});

// ---------------------------------------------------------------------------
// POST /api/auth/professional/login — login profissional
// ---------------------------------------------------------------------------
router.post('/professional/login', (req, res) => {
  const error = validateLogin(req.body);
  if (error) return fail(req, res, '/login-profissional.html', error);

  const { email, password } = req.body;
  const normalizedEmail = email.trim().toLowerCase();

  const professional = db.prepare('SELECT * FROM professionals WHERE email = ?').get(normalizedEmail);
  const passwordOk = professional && bcrypt.compareSync(password, professional.password_hash);

  if (!passwordOk) {
    return fail(req, res, '/login-profissional.html', 'E-mail ou senha inválidos.', 401);
  }

  if (professional.verification_status !== 'approved') {
    return fail(
      req,
      res,
      '/login-profissional.html',
      'Seu CRP ainda está em análise. Avisaremos por e-mail assim que sua conta for aprovada.',
      403
    );
  }

  req.session.regenerate((err) => {
    if (err) return fail(req, res, '/login-profissional.html', 'Não foi possível iniciar a sessão. Tente novamente.', 500);

    req.session.account = {
      type: 'professional',
      id: professional.id,
      full_name: professional.full_name,
      email: professional.email,
      specialty: professional.specialty,
    };

    const requestedRedirect = req.body.redirect;
    const target = PROTECTED_PAGES.includes(requestedRedirect) ? requestedRedirect : '/painel-psicologo.html';

    return succeed(req, res, target, { account: req.session.account });
  });
});

// ---------------------------------------------------------------------------
// GET /api/auth/logout — usado pelos links "Sair" do painel
// ---------------------------------------------------------------------------
router.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.clearCookie('mt.sid');
    res.redirect('/selecionar-perfil.html');
  });
});

// ---------------------------------------------------------------------------
// GET /api/auth/me — checagem de sessão (útil para as próximas telas)
// ---------------------------------------------------------------------------
router.get('/me', (req, res) => {
  if (!req.session.account) {
    return res.status(401).json({ ok: false, authenticated: false });
  }
  return res.json({ ok: true, authenticated: true, account: req.session.account });
});

// ---------------------------------------------------------------------------
// Recuperação de senha
// ---------------------------------------------------------------------------
// Procura o e-mail nas duas tabelas (usuário "jovem" e profissional) e
// devolve qual delas bateu, já que recuperar-senha.html tem um único campo
// de e-mail (sem precisar perguntar o tipo de conta).
function findAccountByEmail(normalizedEmail) {
  const user = db.prepare('SELECT id, full_name, email FROM users WHERE email = ?').get(normalizedEmail);
  if (user) return { type: 'user', ...user };

  const professional = db
    .prepare('SELECT id, full_name, email FROM professionals WHERE email = ?')
    .get(normalizedEmail);
  if (professional) return { type: 'professional', ...professional };

  return null;
}

function hashToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

// ---------------------------------------------------------------------------
// POST /api/auth/password/esqueci — gera um link de redefinição de senha
// ---------------------------------------------------------------------------
router.post('/password/esqueci', (req, res) => {
  const error = validateForgotPassword(req.body);
  if (error) return fail(req, res, '/recuperar-senha.html', error);

  const normalizedEmail = req.body.email.trim().toLowerCase();
  const account = findAccountByEmail(normalizedEmail);

  // Resposta é sempre a mesma exista ou não a conta, para não revelar a
  // quem está testando e-mails se um endereço está cadastrado ou não.
  const redirectTo = '/recuperar-senha.html?sent=1';

  if (!account) return succeed(req, res, redirectTo);

  const token = crypto.randomBytes(32).toString('hex');
  const tokenHash = hashToken(token);
  const expiresAt = new Date(Date.now() + RESET_TOKEN_TTL_MINUTES * 60 * 1000).toISOString();

  db.prepare(
    `INSERT INTO password_resets (account_type, account_id, token_hash, expires_at) VALUES (?, ?, ?, ?)`
  ).run(account.type, account.id, tokenHash, expiresAt);

  const resetLink = `/redefinir-senha.html?token=${token}`;

  // TODO (produto): não há envio de e-mail configurado neste projeto (sem
  // SMTP/SendGrid). Em produção, troque este console.log por um envio real
  // do link por e-mail para account.email — NUNCA exponha o link na resposta
  // HTTP em produção. Enquanto isso, fora de produção, devolvemos o link
  // direto na URL só para dar pra testar o fluxo sem servidor de e-mail.
  console.log(`[recuperação de senha] link para ${account.email}: ${resetLink}`);

  if (process.env.NODE_ENV === 'production') {
    return succeed(req, res, redirectTo);
  }
  return succeed(req, res, `${redirectTo}&dev_link=${encodeURIComponent(resetLink)}`);
});

// ---------------------------------------------------------------------------
// POST /api/auth/password/redefinir — confirma o token e troca a senha
// ---------------------------------------------------------------------------
router.post('/password/redefinir', (req, res) => {
  // Monta o redirect de erro na mão (em vez de usar fail() direto) porque
  // esta página precisa manter ?token=... na URL além de ?error=...
  function failWithToken(message) {
    if (wantsJson(req)) return res.status(400).json({ ok: false, error: message });
    const query = new URLSearchParams({ token: req.body.token || '', error: message }).toString();
    return res.redirect(`/redefinir-senha.html?${query}`);
  }

  const error = validateResetPassword(req.body);
  if (error) return failWithToken(error);

  const tokenHash = hashToken(req.body.token);
  const resetRow = db
    .prepare(`SELECT * FROM password_resets WHERE token_hash = ? AND used_at IS NULL`)
    .get(tokenHash);

  if (!resetRow || new Date(resetRow.expires_at).getTime() < Date.now()) {
    return fail(
      req,
      res,
      '/recuperar-senha.html',
      'Esse link de recuperação é inválido ou expirou. Peça um novo.'
    );
  }

  const password_hash = bcrypt.hashSync(req.body.password, SALT_ROUNDS);
  const table = resetRow.account_type === 'professional' ? 'professionals' : 'users';

  const updateAndConsume = db.transaction(() => {
    db.prepare(`UPDATE ${table} SET password_hash = ? WHERE id = ?`).run(password_hash, resetRow.account_id);
    db.prepare(`UPDATE password_resets SET used_at = datetime('now') WHERE id = ?`).run(resetRow.id);
    // Invalida quaisquer outros links de recuperação pendentes para a mesma conta.
    db.prepare(
      `UPDATE password_resets SET used_at = datetime('now')
       WHERE account_type = ? AND account_id = ? AND used_at IS NULL`
    ).run(resetRow.account_type, resetRow.account_id);
  });
  updateAndConsume();

  const loginPage = resetRow.account_type === 'professional' ? '/login-profissional.html' : '/login.html';
  return succeed(req, res, `${loginPage}?reset=1`);
});

module.exports = router;
