// Sistema de marcar consultas.
// Casa com os formulários/telas já existentes no frontend:
//   GET   /api/psicologos                        <- psicologos.html
//   GET   /api/psicologos/:id/horarios?data=      <- agendar-consulta.html (calendário/horários)
//   POST  /api/consultas                          <- agendar-consulta.html (form de agendamento)
//   GET   /api/consultas/:id                      <- agendamento-confirmado.html
//   GET   /api/consultas                          <- dashboard.html / painel-psicologo.html / consultas.html / agenda(s)
//   PATCH /api/consultas/:id/cancelar             <- botão "Cancelar" (usuário ou profissional)
//   PATCH /api/consultas/:id/confirmar            <- painel do profissional (consulta pendente -> confirmada)

const express = require('express');
const db = require('../db/database');

const router = express.Router();

function wantsJson(req) {
  return req.get('accept') && req.get('accept').includes('application/json');
}
function fail(req, res, redirectTo, message, status = 400) {
  if (wantsJson(req) || !redirectTo) return res.status(status).json({ ok: false, error: message });
  return res.redirect(`${redirectTo}?error=${encodeURIComponent(message)}`);
}
function succeed(req, res, redirectTo, payload = {}) {
  if (wantsJson(req) || !redirectTo) return res.status(200).json({ ok: true, ...payload });
  return res.redirect(redirectTo);
}

function requireUser(req, res, next) {
  if (req.session.account && req.session.account.type === 'user') return next();
  return res.status(401).json({ ok: false, error: 'Faça login para continuar.' });
}
function requireProfessional(req, res, next) {
  if (req.session.account && req.session.account.type === 'professional') return next();
  return res.status(401).json({ ok: false, error: 'Faça login para continuar.' });
}

const WEEKDAY_LABELS = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];

// Mesmos valores/rótulos do <select> de especialidade em cadastro-profissional.html
// (server/utils/validators.js::ALLOWED_SPECIALTIES) — centralizado aqui para
// que a busca (psicologos.html) e o perfil (perfil-psicologo.html) usem
// sempre o mesmo texto.
const SPECIALTY_LABELS = {
  clinica: 'Psicologia Clínica',
  infantil: 'Psicologia Infantil',
  cognitivo_comportamental: 'Terapia Cognitivo-Comportamental',
  familiar: 'Terapia Familiar e de Casal',
  neuropsicologia: 'Neuropsicologia',
  organizacional: 'Psicologia Organizacional',
};
function specialtyLabel(code) {
  return SPECIALTY_LABELS[code] || code;
}

// Próximos N horários livres de um profissional, varrendo os próximos 14
// dias — usado no card de busca ("Disponível hoje/esta semana") e no perfil
// (pílulas de horário que levam direto para o agendamento).
function nextAvailableSlots(professionalId, limit) {
  const exceptions = new Set(
    db.prepare(`SELECT date FROM availability_exceptions WHERE professional_id = ?`).all(professionalId).map((r) => r.date)
  );
  const rangesByWeekday = {};
  db.prepare(`SELECT weekday, start_time, end_time FROM availability_slots WHERE professional_id = ?`)
    .all(professionalId)
    .forEach((r) => {
      rangesByWeekday[r.weekday] = rangesByWeekday[r.weekday] || [];
      rangesByWeekday[r.weekday].push(r);
    });
  const booked = new Set(
    db
      .prepare(`SELECT date, time FROM consultations WHERE professional_id = ? AND status != 'cancelada'`)
      .all(professionalId)
      .map((r) => r.date + ' ' + r.time)
  );

  const results = [];
  for (let i = 0; i < 14 && results.length < limit; i++) {
    const d = new Date();
    d.setDate(d.getDate() + i);
    const iso = d.toISOString().slice(0, 10);
    if (exceptions.has(iso)) continue;
    const ranges = rangesByWeekday[d.getDay()] || [];
    ranges.forEach((r) => {
      expandHourlySlots(r.start_time, r.end_time).forEach((time) => {
        if (results.length >= limit) return;
        if (booked.has(iso + ' ' + time)) return;
        results.push({ date: iso, time });
      });
    });
  }
  return results;
}

// Gera os horários "HH:00" entre start e end (exclusive do fim), ex: 08:00-12:00 -> [08:00, ..., 11:00]
function expandHourlySlots(startTime, endTime) {
  const [sh] = startTime.split(':').map(Number);
  const [eh] = endTime.split(':').map(Number);
  const slots = [];
  for (let h = sh; h < eh; h++) slots.push(String(h).padStart(2, '0') + ':00');
  return slots;
}

// ---------------------------------------------------------------------------
// GET /api/psicologos?query=&especialidade= — profissionais aprovados
// (busca em psicologos.html). Filtra no servidor: "query" bate em nome,
// especialidade ou CRP; "especialidade" é o valor exato do <select>.
// ---------------------------------------------------------------------------
router.get('/psicologos', (req, res) => {
  const query = (req.query.query || '').trim().toLowerCase();
  const especialidade = (req.query.especialidade || '').trim();

  let rows = db
    .prepare(
      `SELECT id, full_name, crp_number, specialty, bio, experience, approach, modality
       FROM professionals WHERE verification_status = 'approved'`
    )
    .all();

  if (especialidade) rows = rows.filter((p) => p.specialty === especialidade);

  if (query) {
    rows = rows.filter((p) => {
      const haystack = (p.full_name + ' ' + specialtyLabel(p.specialty) + ' ' + p.specialty + ' ' + p.crp_number).toLowerCase();
      return haystack.indexOf(query) !== -1;
    });
  }

  rows.sort((a, b) => a.full_name.localeCompare(b.full_name));

  const psicologos = rows.map((p) => ({
    id: p.id,
    full_name: p.full_name,
    crp_number: p.crp_number,
    specialty: p.specialty,
    specialty_label: specialtyLabel(p.specialty),
    bio: p.bio || null,
    modality: p.modality,
  }));

  res.json({ ok: true, psicologos, specialties: SPECIALTY_LABELS });
});

// ---------------------------------------------------------------------------
// GET /api/psicologos/:id — perfil público de um profissional aprovado
// (perfil-psicologo.html)
// ---------------------------------------------------------------------------
router.get('/psicologos/:id', (req, res) => {
  const professional = db
    .prepare(
      `SELECT id, full_name, crp_number, specialty, bio, experience, approach, modality
       FROM professionals WHERE id = ? AND verification_status = 'approved'`
    )
    .get(Number(req.params.id));

  if (!professional) return res.status(404).json({ ok: false, error: 'Profissional não encontrado.' });

  res.json({
    ok: true,
    psicologo: {
      id: professional.id,
      full_name: professional.full_name,
      crp_number: professional.crp_number,
      specialty: professional.specialty,
      specialty_label: specialtyLabel(professional.specialty),
      bio: professional.bio || 'Este profissional ainda não preencheu sua biografia.',
      experience: professional.experience || 'Não informado',
      approach: professional.approach || 'Não informado',
      modality: professional.modality,
      next_available: nextAvailableSlots(professional.id, 6),
    },
  });
});

// ---------------------------------------------------------------------------
// GET /api/psicologos/:id/horarios?data=YYYY-MM-DD — horários livres num dia
// ---------------------------------------------------------------------------
router.get('/psicologos/:id/horarios', (req, res) => {
  const professionalId = Number(req.params.id);
  const { data } = req.query;

  if (!data || !/^\d{4}-\d{2}-\d{2}$/.test(data)) {
    return res.status(400).json({ ok: false, error: 'Informe uma data válida (YYYY-MM-DD).' });
  }

  const professional = db
    .prepare(`SELECT id FROM professionals WHERE id = ? AND verification_status = 'approved'`)
    .get(professionalId);
  if (!professional) return res.status(404).json({ ok: false, error: 'Profissional não encontrado.' });

  const exception = db
    .prepare(`SELECT id FROM availability_exceptions WHERE professional_id = ? AND date = ?`)
    .get(professionalId, data);
  if (exception) return res.json({ ok: true, horarios: [] });

  const weekday = new Date(data + 'T12:00:00').getDay();
  const ranges = db
    .prepare(`SELECT start_time, end_time FROM availability_slots WHERE professional_id = ? AND weekday = ?`)
    .all(professionalId, weekday);

  let slots = [];
  ranges.forEach((r) => { slots = slots.concat(expandHourlySlots(r.start_time, r.end_time)); });

  const booked = db
    .prepare(
      `SELECT time FROM consultations WHERE professional_id = ? AND date = ? AND status != 'cancelada'`
    )
    .all(professionalId, data)
    .map((r) => r.time);

  const horarios = slots.filter((s) => booked.indexOf(s) === -1).sort();
  res.json({ ok: true, horarios });
});

// ---------------------------------------------------------------------------
// POST /api/consultas — marcar uma consulta (usuário "jovem")
// ---------------------------------------------------------------------------
router.post('/consultas', requireUser, (req, res) => {
  const redirectTo = '/agendar-consulta.html';
  const { psicologo_id, data, horario } = req.body;

  if (!psicologo_id || !data || !horario) {
    return fail(req, res, redirectTo, 'Selecione um profissional, uma data e um horário.');
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(data) || !/^\d{2}:\d{2}$/.test(horario)) {
    return fail(req, res, redirectTo, 'Data ou horário inválidos.');
  }

  const professional = db
    .prepare(`SELECT id FROM professionals WHERE id = ? AND verification_status = 'approved'`)
    .get(Number(psicologo_id));
  if (!professional) return fail(req, res, redirectTo, 'Profissional não encontrado.');

  const weekday = new Date(data + 'T12:00:00').getDay();
  const withinAvailability = db
    .prepare(
      `SELECT id FROM availability_slots WHERE professional_id = ? AND weekday = ? AND start_time <= ? AND end_time > ?`
    )
    .get(professional.id, weekday, horario, horario);
  const blockedDate = db
    .prepare(`SELECT id FROM availability_exceptions WHERE professional_id = ? AND date = ?`)
    .get(professional.id, data);

  if (!withinAvailability || blockedDate) {
    return fail(req, res, redirectTo, 'Esse horário não está mais disponível. Escolha outro.');
  }

  try {
    const insert = db.prepare(
      `INSERT INTO consultations (user_id, professional_id, date, time, status) VALUES (?, ?, ?, ?, 'confirmada')`
    );
    const result = insert.run(req.session.account.id, professional.id, data, horario);
    return succeed(req, res, `/agendamento-confirmado.html?id=${result.lastInsertRowid}`, {
      consulta_id: result.lastInsertRowid,
    });
  } catch (err) {
    // UNIQUE (professional_id, date, time) — alguém marcou esse mesmo horário primeiro
    return fail(req, res, redirectTo, 'Esse horário acabou de ser reservado por outra pessoa. Escolha outro.');
  }
});

// ---------------------------------------------------------------------------
// GET /api/consultas/:id — detalhe (agendamento-confirmado.html)
// ---------------------------------------------------------------------------
router.get('/consultas/:id', (req, res) => {
  if (!req.session.account) return res.status(401).json({ ok: false, error: 'Faça login para continuar.' });

  const row = db
    .prepare(
      `SELECT c.*, p.full_name AS professional_name, u.full_name AS user_name
       FROM consultations c
       JOIN professionals p ON p.id = c.professional_id
       JOIN users u ON u.id = c.user_id
       WHERE c.id = ?`
    )
    .get(Number(req.params.id));

  if (!row) return res.status(404).json({ ok: false, error: 'Consulta não encontrada.' });

  const account = req.session.account;
  const owns =
    (account.type === 'user' && account.id === row.user_id) ||
    (account.type === 'professional' && account.id === row.professional_id);
  if (!owns) return res.status(403).json({ ok: false, error: 'Sem permissão.' });

  res.json({ ok: true, consulta: row });
});

// ---------------------------------------------------------------------------
// GET /api/consultas — lista as consultas da conta logada
// query opcional: ?range=hoje|proximos|semana|todas|canceladas (default: todas)
// ---------------------------------------------------------------------------
router.get('/consultas', (req, res) => {
  if (!req.session.account) return res.status(401).json({ ok: false, error: 'Faça login para continuar.' });
  const account = req.session.account;
  const range = req.query.range || 'todas';

  const isProfessional = account.type === 'professional';
  const ownerColumn = isProfessional ? 'c.professional_id' : 'c.user_id';
  const nameColumn = isProfessional ? 'u.full_name AS other_name' : 'p.full_name AS other_name';

  let where = `${ownerColumn} = ?`;
  const params = [account.id];
  const today = new Date().toISOString().slice(0, 10);

  if (range === 'hoje') { where += ` AND c.date = ? AND c.status != 'cancelada'`; params.push(today); }
  else if (range === 'proximos' || range === 'semana') { where += ` AND c.date >= ? AND c.status != 'cancelada'`; params.push(today); }
  else if (range === 'canceladas') { where += ` AND c.status = 'cancelada'`; }

  const rows = db
    .prepare(
      `SELECT c.id, c.date, c.time, c.status, ${nameColumn}
       FROM consultations c
       JOIN users u ON u.id = c.user_id
       JOIN professionals p ON p.id = c.professional_id
       WHERE ${where}
       ORDER BY c.date ASC, c.time ASC`
    )
    .all(...params);

  res.json({ ok: true, consultas: rows });
});

// ---------------------------------------------------------------------------
// PATCH /api/consultas/:id/cancelar — usuário ou profissional cancela
// ---------------------------------------------------------------------------
router.patch('/consultas/:id/cancelar', (req, res) => {
  if (!req.session.account) return res.status(401).json({ ok: false, error: 'Faça login para continuar.' });
  const account = req.session.account;
  const row = db.prepare('SELECT * FROM consultations WHERE id = ?').get(Number(req.params.id));
  if (!row) return res.status(404).json({ ok: false, error: 'Consulta não encontrada.' });

  const owns =
    (account.type === 'user' && account.id === row.user_id) ||
    (account.type === 'professional' && account.id === row.professional_id);
  if (!owns) return res.status(403).json({ ok: false, error: 'Sem permissão.' });

  db.prepare(`UPDATE consultations SET status = 'cancelada' WHERE id = ?`).run(row.id);
  res.json({ ok: true });
});

// ---------------------------------------------------------------------------
// PATCH /api/consultas/:id/confirmar — profissional confirma uma consulta pendente
// ---------------------------------------------------------------------------
router.patch('/consultas/:id/confirmar', requireProfessional, (req, res) => {
  const row = db.prepare('SELECT * FROM consultations WHERE id = ?').get(Number(req.params.id));
  if (!row || row.professional_id !== req.session.account.id) {
    return res.status(404).json({ ok: false, error: 'Consulta não encontrada.' });
  }
  db.prepare(`UPDATE consultations SET status = 'confirmada' WHERE id = ?`).run(row.id);
  res.json({ ok: true });
});

module.exports = router;
