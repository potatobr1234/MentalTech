// Abre (ou cria) o arquivo SQLite e garante que as tabelas do schema.sql existam.
// Usa better-sqlite3: API síncrona, sem callbacks/promises, ótima para um
// projeto pequeno como este.

const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'mental_tech.sqlite3');
const SCHEMA_PATH = path.join(__dirname, 'schema.sql');

const db = new Database(DB_PATH);

// Boas práticas padrão para SQLite em uma aplicação web.
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// Cria as tabelas caso ainda não existam (idempotente — seguro rodar toda vez).
const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
db.exec(schema);

// Migração leve para bancos criados antes dos campos de perfil do
// profissional existirem: SQLite não tem "ADD COLUMN IF NOT EXISTS", então
// checamos o que já existe via PRAGMA e só adicionamos o que falta.
// Idempotente e segura de rodar toda vez que o servidor sobe.
(function ensureProfessionalProfileColumns() {
  const existing = db.prepare("PRAGMA table_info(professionals)").all().map((c) => c.name);
  const wanted = {
    bio: 'TEXT',
    experience: 'TEXT',
    approach: 'TEXT',
    modality: "TEXT NOT NULL DEFAULT 'Online e presencial'",
  };
  Object.keys(wanted).forEach((column) => {
    if (!existing.includes(column)) {
      db.exec(`ALTER TABLE professionals ADD COLUMN ${column} ${wanted[column]}`);
    }
  });
})();

module.exports = db;
