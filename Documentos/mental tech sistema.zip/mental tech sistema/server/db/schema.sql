-- Mental Tech — schema do sistema de login e cadastro (SQLite)
-- Executado automaticamente em server/db/database.js ao iniciar o servidor.

-- Contas de usuários ("jovem"), criadas em cadastro.html / autenticadas em login.html
CREATE TABLE IF NOT EXISTS users (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  full_name       TEXT NOT NULL,
  email           TEXT NOT NULL UNIQUE COLLATE NOCASE,
  birth_date      TEXT NOT NULL,             -- YYYY-MM-DD
  password_hash   TEXT NOT NULL,             -- bcrypt hash, nunca a senha em texto puro
  terms_accepted_at TEXT NOT NULL,
  created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

-- Contas profissionais (psicólogos), criadas em cadastro-profissional.html /
-- autenticadas em login-profissional.html
CREATE TABLE IF NOT EXISTS professionals (
  id                   INTEGER PRIMARY KEY AUTOINCREMENT,
  full_name            TEXT NOT NULL,
  email                TEXT NOT NULL UNIQUE COLLATE NOCASE,
  crp_number           TEXT NOT NULL UNIQUE COLLATE NOCASE,  -- ex: SP/12345
  specialty            TEXT NOT NULL,
  password_hash        TEXT NOT NULL,
  verification_status  TEXT NOT NULL DEFAULT 'pending'
                        CHECK (verification_status IN ('pending', 'approved', 'rejected')),
  -- Preenchidos depois do cadastro (ainda sem tela de edição própria — ver
  -- TODO em routes/psicologo.js); até lá o sistema de seleção usa valores
  -- padrão razoáveis no lugar destes campos quando estiverem vazios.
  bio                  TEXT,
  experience           TEXT,
  approach             TEXT,
  modality             TEXT NOT NULL DEFAULT 'Online e presencial',
  created_at           TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_professionals_email ON professionals(email);
CREATE INDEX IF NOT EXISTS idx_professionals_crp ON professionals(crp_number);

-- Tokens de recuperação de senha (recuperar-senha.html / redefinir-senha.html).
-- account_type diferencia se o token é de "users" ou "professionals".
-- Guardamos só o HASH do token (nunca o token em texto puro) — o mesmo
-- princípio usado para password_hash.
CREATE TABLE IF NOT EXISTS password_resets (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  account_type    TEXT NOT NULL CHECK (account_type IN ('user', 'professional')),
  account_id      INTEGER NOT NULL,
  token_hash      TEXT NOT NULL UNIQUE,
  expires_at      TEXT NOT NULL,
  used_at         TEXT,
  created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_password_resets_token ON password_resets(token_hash);
CREATE INDEX IF NOT EXISTS idx_password_resets_account ON password_resets(account_type, account_id);

-- Horários semanais de atendimento de cada profissional (disponibilidade.html)
-- weekday: 0=domingo .. 6=sábado
CREATE TABLE IF NOT EXISTS availability_slots (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  professional_id INTEGER NOT NULL REFERENCES professionals(id) ON DELETE CASCADE,
  weekday         INTEGER NOT NULL CHECK (weekday BETWEEN 0 AND 6),
  start_time      TEXT NOT NULL, -- HH:MM
  end_time        TEXT NOT NULL  -- HH:MM
);

CREATE INDEX IF NOT EXISTS idx_availability_professional ON availability_slots(professional_id);

-- Datas específicas em que o profissional NÃO está disponível (exceções)
CREATE TABLE IF NOT EXISTS availability_exceptions (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  professional_id INTEGER NOT NULL REFERENCES professionals(id) ON DELETE CASCADE,
  date            TEXT NOT NULL, -- YYYY-MM-DD
  reason          TEXT
);

CREATE INDEX IF NOT EXISTS idx_exceptions_professional ON availability_exceptions(professional_id);

-- Consultas agendadas entre um usuário (jovem) e um profissional
CREATE TABLE IF NOT EXISTS consultations (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id         INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  professional_id INTEGER NOT NULL REFERENCES professionals(id) ON DELETE CASCADE,
  date            TEXT NOT NULL,   -- YYYY-MM-DD
  time            TEXT NOT NULL,   -- HH:MM
  status          TEXT NOT NULL DEFAULT 'confirmada'
                  CHECK (status IN ('pendente', 'confirmada', 'concluida', 'cancelada')),
  created_at      TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (professional_id, date, time)
);

CREATE INDEX IF NOT EXISTS idx_consultations_user ON consultations(user_id);
CREATE INDEX IF NOT EXISTS idx_consultations_professional ON consultations(professional_id);
CREATE INDEX IF NOT EXISTS idx_consultations_date ON consultations(date);
