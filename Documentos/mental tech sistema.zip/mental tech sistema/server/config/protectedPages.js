// Páginas que exigem login, separadas por tipo de conta. Usado pelo
// middleware de guarda em server.js e pela validação do campo "redirect"
// no login (routes/auth.js), para evitar open redirect (só se redireciona
// para páginas destas listas).

// Só acessíveis por uma conta tipo "user" (jovem)
const USER_PAGES = [
  '/psicologos.html',
  '/perfil-psicologo.html',
  '/agendar-consulta.html',
  '/agendamento-confirmado.html',
  '/dashboard.html',
  '/agenda.html',
  '/configuracoes.html',
];

// Só acessíveis por uma conta tipo "professional" (psicólogo)
const PROFESSIONAL_PAGES = [
  '/painel-psicologo.html',
  '/consultas.html',
  '/agenda-psicologo.html',
  '/pacientes.html',
  '/mensagens.html',
  '/disponibilidade.html',
  '/meu-perfil-psicologo.html',
  '/configuracoes-psicologo.html',
];

module.exports = {
  USER_PAGES,
  PROFESSIONAL_PAGES,
  ALL: USER_PAGES.concat(PROFESSIONAL_PAGES),
};
