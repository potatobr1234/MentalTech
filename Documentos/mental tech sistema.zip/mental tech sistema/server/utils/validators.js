// Validações usadas pelas rotas de cadastro/login.
// Mantidas simples e sem dependências externas.

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Aceita formatos como "SP/12345", "sp/123456" (CRP = UF/número, 4 a 6 dígitos)
const CRP_RE = /^[A-Za-z]{2}\/\d{4,6}$/;

const ALLOWED_SPECIALTIES = [
  'clinica',
  'infantil',
  'cognitivo_comportamental',
  'familiar',
  'neuropsicologia',
  'organizacional',
];

function isValidEmail(email) {
  return typeof email === 'string' && EMAIL_RE.test(email.trim());
}

function isValidCrp(crp) {
  return typeof crp === 'string' && CRP_RE.test(crp.trim());
}

function isValidSpecialty(specialty) {
  return ALLOWED_SPECIALTIES.includes(specialty);
}

// Idade mínima de 18 anos, coerente com o público-alvo descrito em sobre.html.
function isOldEnough(birthDateStr, minAge) {
  const birthDate = new Date(birthDateStr);
  if (Number.isNaN(birthDate.getTime())) return false;

  const today = new Date();
  let age = today.getFullYear() - birthDate.getFullYear();
  const monthDiff = today.getMonth() - birthDate.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  return age >= minAge;
}

function validateRegisterUser(body) {
  const { full_name, email, birth_date, password, password_confirm, terms_accepted } = body;

  if (!full_name || !full_name.trim()) return 'Informe seu nome completo.';
  if (!isValidEmail(email)) return 'Informe um e-mail válido.';
  if (!birth_date) return 'Informe sua data de nascimento.';
  if (!isOldEnough(birth_date, 18)) return 'É necessário ter 18 anos ou mais para se cadastrar.';
  if (!password || password.length < 8) return 'A senha deve ter no mínimo 8 caracteres.';
  if (password !== password_confirm) return 'As senhas não coincidem.';
  if (!terms_accepted) return 'É necessário aceitar os termos de uso e a política de privacidade.';

  return null; // sem erros
}

function validateRegisterProfessional(body) {
  const { full_name, email, crp_number, specialty, password, password_confirm } = body;

  if (!full_name || !full_name.trim()) return 'Informe seu nome completo.';
  if (!isValidEmail(email)) return 'Informe um e-mail profissional válido.';
  if (!isValidCrp(crp_number)) return 'Informe o CRP no formato UF/00000 (ex: SP/12345).';
  if (!isValidSpecialty(specialty)) return 'Selecione uma especialidade válida.';
  if (!password || password.length < 8) return 'A senha deve ter no mínimo 8 caracteres.';
  if (password !== password_confirm) return 'As senhas não coincidem.';

  return null;
}

function validateLogin(body) {
  const { email, password } = body;
  if (!isValidEmail(email) || !password) return 'Informe e-mail e senha.';
  return null;
}

function validateForgotPassword(body) {
  const { email } = body;
  if (!isValidEmail(email)) return 'Informe um e-mail válido.';
  return null;
}

function validateResetPassword(body) {
  const { token, password, password_confirm } = body;
  if (!token || typeof token !== 'string') return 'Link de recuperação inválido.';
  if (!password || password.length < 8) return 'A senha deve ter no mínimo 8 caracteres.';
  if (password !== password_confirm) return 'As senhas não coincidem.';
  return null;
}

module.exports = {
  isValidEmail,
  isValidCrp,
  isValidSpecialty,
  isOldEnough,
  validateRegisterUser,
  validateRegisterProfessional,
  validateLogin,
  validateForgotPassword,
  validateResetPassword,
};
