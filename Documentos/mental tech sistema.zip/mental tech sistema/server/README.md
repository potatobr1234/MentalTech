# Mental Tech — servidor de login e cadastro

Backend em **Node.js + Express + SQLite** que implementa, de ponta a ponta, o
sistema de cadastro e login já desenhado no front-end (`cadastro.html`,
`login.html`, `cadastro-profissional.html`, `login-profissional.html`).

Escopo desta entrega: **apenas autenticação** (cadastro, login, logout e
checagem de sessão). Nenhuma outra funcionalidade (agenda, dashboard, chat
etc.) foi implementada no backend — essas páginas continuam sendo front-end
estático com dados de exemplo.

## O que foi implementado

- Banco **SQLite** com duas tabelas (`db/schema.sql`):
  - `users` — contas de jovens, criadas em `cadastro.html`
  - `professionals` — contas de psicólogos, criadas em `cadastro-profissional.html`, com `verification_status` (`pending` / `approved` / `rejected`)
- Senhas nunca são salvas em texto puro — usamos **bcrypt** (`bcryptjs`) para gerar o hash antes de gravar no banco.
- Sessão de login via cookie **httpOnly** (`express-session`, guardada no próprio SQLite).
- Validações no servidor (iguais às descritas nos comentários `TODO` que já existiam no HTML):
  - E-mail em formato válido e único
  - Senha com no mínimo 8 caracteres e igual à confirmação
  - Termos de uso aceitos (cadastro de usuário)
  - Idade mínima de 18 anos (cadastro de usuário)
  - CRP no formato `UF/00000` e único (cadastro profissional)
  - Especialidade dentro da lista permitida (cadastro profissional)
- Login profissional **bloqueia o acesso** enquanto `verification_status` não for `approved` (ver seção "Aprovar um profissional" abaixo).
- Rotas:

| Método | Rota                          | Usado por                        |
|--------|-------------------------------|-----------------------------------|
| POST   | `/api/auth/register`               | `cadastro.html`                  |
| POST   | `/api/auth/login`                  | `login.html`                     |
| POST   | `/api/auth/professional/register`  | `cadastro-profissional.html`     |
| POST   | `/api/auth/professional/login`     | `login-profissional.html`        |
| GET    | `/api/auth/logout`                 | links "Sair" do painel logado    |
| GET    | `/api/auth/me`                     | checagem de sessão (uso futuro)  |
| POST   | `/api/auth/password/esqueci`       | `recuperar-senha.html`           |
| POST   | `/api/auth/password/redefinir`     | `redefinir-senha.html`           |

Os `<form action="...">` do HTML já apontavam exatamente para essas rotas
(eram os `TODO (backend)` deixados no front-end), então **nenhum HTML
precisou ter o endpoint alterado** — só foi adicionado um pequeno aviso de
erro/sucesso (`js/auth-messages.js`) que lê `?error=` / `?registered=1` /
`?pending=1` da URL depois de um redirect do servidor.

## Como rodar

O jeito mais fácil (só precisa do [Node.js](https://nodejs.org) 18+ instalado):

- **Windows:** dê duplo clique em `iniciar.bat` (na raiz do projeto)
- **Mac:** dê duplo clique em `iniciar.command`
- **Qualquer sistema:** na raiz do projeto, `node server/scripts/iniciar.js` (ou `npm start`)

Na primeira vez ele cria o `server/.env` com um `SESSION_SECRET` aleatório,
roda o `npm install` sozinho e abre o site no navegador. Nas próximas vezes
só sobe o servidor. (Use `--sem-navegador` para não abrir o navegador.)

Manualmente, se preferir:

```bash
cd server
cp .env.example .env      # ajuste SESSION_SECRET
npm install
npm start
```

O servidor sobe em `http://localhost:3000` e já serve o site inteiro (pasta
`../Mental tech html`) — não precisa abrir os arquivos `.html` direto no
navegador, acesse tudo por `http://localhost:3000`.

Ao iniciar pela primeira vez, o arquivo `server/db/mental_tech.sqlite3` é
criado automaticamente com as tabelas do `schema.sql`.

## Fluxo de teste rápido

1. Acesse `http://localhost:3000/cadastro.html` e crie uma conta de usuário → redireciona para o login com uma mensagem de sucesso.
2. Faça login em `http://localhost:3000/login.html` → sessão criada, redireciona para `dashboard.html`.
3. Clique em "Sair" no menu do painel → sessão encerrada, volta para `selecionar-perfil.html`.
4. Acesse `cadastro-profissional.html` e crie uma conta profissional → fica com `verification_status = "pending"`.
5. Tente logar em `login-profissional.html` com essa conta → é bloqueado com a mensagem "CRP ainda está em análise" (comportamento esperado até a conta ser aprovada — veja abaixo).

## Recuperação de senha

Funciona para contas de usuário e profissional com o mesmo formulário
(`recuperar-senha.html` pede só o e-mail; o backend identifica sozinho em
qual das duas tabelas ele está).

1. `recuperar-senha.html` → `POST /api/auth/password/esqueci` gera um token
   aleatório (válido por 30 min), grava só o **hash** dele em
   `password_resets` e monta o link `redefinir-senha.html?token=...`.
2. **Não há envio de e-mail configurado neste projeto** (sem SMTP/SendGrid
   nas dependências). Fora de produção (`NODE_ENV` ≠ `production`), o link
   aparece direto na tela de "recuperar senha" (e também no console do
   servidor) só pra dar pra testar o fluxo sem precisar de um servidor de
   e-mail de verdade. Em produção esse atalho é desativado automaticamente —
   antes de ir pra produção, troque o `console.log` em
   `routes/auth.js` (`POST /password/esqueci`) por um envio real.
3. `redefinir-senha.html?token=...` → `POST /api/auth/password/redefinir`
   confere o token (hash, validade de 30 min, uso único), troca a senha e
   invalida qualquer outro link pendente da mesma conta.

A resposta de `/password/esqueci` é sempre a mesma exista ou não o e-mail,
pra não dar pra descobrir por tentativa e erro quais e-mails têm conta.

## Seleção de psicólogos

`psicologos.html` e `perfil-psicologo.html` usam só profissionais com
`verification_status = 'approved'` (ver "Aprovar um profissional
manualmente" abaixo).

- `GET /api/psicologos?query=&especialidade=` — busca por nome/CRP/especialidade
  e filtro por especialidade, usada em `js/psicologos-busca.js`. O filtro de
  "Atendimento" (online/presencial) é só client-side sobre a resposta.
- `GET /api/psicologos/:id` — perfil público (`js/perfil-psicologo.js`),
  incluindo até 6 próximos horários livres (`next_available`), cada um
  virando um link direto para `agendar-consulta.html?psicologo_id=&data=&horario=`
  já com o dia/horário pré-selecionado.

Os campos `bio`, `experience` e `approach` do profissional (exibidos em
"Sobre mim") ainda não têm tela de edição — hoje só existem no banco com
valor `NULL` até alguém editar direto no banco, e a página mostra um texto
padrão ("ainda não preencheu sua biografia" / "Não informado") nesse caso.
`modality` já vem com um valor padrão ("Online e presencial") no cadastro.

## Aprovar um profissional manualmente

Como a verificação automática do CRP junto ao Conselho Federal de Psicologia
está fora do escopo desta entrega, aprove um cadastro profissional pela
linha de comando — sem precisar do `npm`, do `sqlite3` CLI, nem do servidor
rodando (basta o `node_modules` já instalado uma vez com `npm install`):

```bash
cd server

# lista os cadastros pendentes de aprovação
node scripts/approve-professional.js

# aprova por e-mail ou por CRP
node scripts/approve-professional.js aprovar profissional@email.com
node scripts/approve-professional.js aprovar SP/12345

# rejeita, se necessário
node scripts/approve-professional.js rejeitar profissional@email.com

# lista todos os profissionais (qualquer status)
node scripts/approve-professional.js listar todos
```

## Estrutura

```
server/
├── server.js              # cria o app Express, sessão e serve o front-end estático
├── package.json
├── .env.example
├── db/
│   ├── schema.sql          # tabelas: users, professionals, password_resets,
│   │                        # availability_slots, availability_exceptions, consultations
│   └── database.js         # abre o SQLite e aplica o schema.sql automaticamente
├── routes/
│   ├── auth.js              # POST /register, /login, /professional/register, /professional/login, /logout, /me
│   ├── consultas.js         # sistema de marcar consultas (psicólogos, horários, agendar, cancelar)
│   └── psicologo.js         # painel do profissional: dashboard, pacientes, disponibilidade
├── scripts/
│   └── approve-professional.js  # comando de linha de comando p/ aprovar/rejeitar profissionais
└── utils/
    └── validators.js        # validações de e-mail, senha, CRP, idade mínima etc.
```

## Próximos passos (fora do escopo desta entrega)

- Endpoint de recuperação de senha (`recuperar-senha.html` já existe no front-end mas ainda não tem rota).
- Painel dedicado ao profissional (hoje o login profissional aprovado só redireciona para a Home).
- Verificação automática do CRP junto ao Conselho Federal de Psicologia antes de aprovar um cadastro.
- Rate limiting nas rotas de login para mitigar força bruta.
