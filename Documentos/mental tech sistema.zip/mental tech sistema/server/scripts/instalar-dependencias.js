#!/usr/bin/env node
// Garante que TODAS as dependências do package.json estão instaladas.
// Se qualquer uma faltar (node_modules ausente, instalação interrompida,
// pasta copiada de outro computador...), roda `npm install` sozinho.
// Usado pelo iniciar.js e pelo "prestart" do package.json.

const path = require('path');
const { spawnSync } = require('child_process');

const SERVER_DIR = path.join(__dirname, '..');
const pkg = require(path.join(SERVER_DIR, 'package.json'));

function faltando() {
  return Object.keys(pkg.dependencies || {}).filter((name) => {
    try { require.resolve(name, { paths: [SERVER_DIR] }); return false; } catch (e) { return true; }
  });
}

let missing = faltando();
if (missing.length) {
  console.log(`▶ Dependências faltando (${missing.join(', ')}). Rodando "npm install"...`);
  const isWindows = process.platform === 'win32';
  const result = spawnSync(isWindows ? 'npm.cmd' : 'npm', ['install'], {
    cwd: SERVER_DIR, stdio: 'inherit', shell: isWindows,
  });
  missing = result.status === 0 ? faltando() : missing;
  if (result.status !== 0 || missing.length) {
    console.error(
      '\n✖ Não foi possível instalar as dependências' + (missing.length ? ` (${missing.join(', ')})` : '') + '.\n' +
      '  - Confira sua conexão com a internet.\n' +
      '  - Se o erro for no "better-sqlite3", use o Node 20 ou 22 (LTS) em https://nodejs.org\n' +
      '  - Tente apagar a pasta server/node_modules e rodar de novo.\n'
    );
    process.exit(1);
  }
}
