#!/usr/bin/env node
// Inicializador "tudo em um": prepara o ambiente e sobe o servidor.
//   1. confere a versão do Node
//   2. cria server/.env (com SESSION_SECRET aleatório) se ainda não existir
//   3. roda `npm install` se server/node_modules ainda não existir
//   4. sobe o servidor e abre o navegador
//
// Uso (da raiz do projeto):  node server/scripts/iniciar.js
// Ou dê duplo clique em iniciar.bat (Windows) / iniciar.command (Mac).
// Para não abrir o navegador:  node server/scripts/iniciar.js --sem-navegador

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');

const SERVER_DIR = path.join(__dirname, '..');
const ENV_PATH = path.join(SERVER_DIR, '.env');
const ENV_EXAMPLE = path.join(SERVER_DIR, '.env.example');
const isWindows = process.platform === 'win32';

function passo(msg) { console.log('▶ ' + msg); }
function sair(msg) { console.error('\n✖ ' + msg + '\n'); process.exit(1); }

// 1) Node >= 18
const major = Number(process.versions.node.split('.')[0]);
if (major < 18) {
  sair(`Node ${process.versions.node} é antigo demais. Instale o Node 18 ou mais novo em https://nodejs.org`);
}

// 2) .env
if (!fs.existsSync(ENV_PATH)) {
  passo('Criando server/.env com um SESSION_SECRET aleatório...');
  let content = fs.existsSync(ENV_EXAMPLE)
    ? fs.readFileSync(ENV_EXAMPLE, 'utf8')
    : 'PORT=3000\nSESSION_SECRET=\nNODE_ENV=development\n';
  const secret = crypto.randomBytes(32).toString('hex');
  content = /^SESSION_SECRET=.*$/m.test(content)
    ? content.replace(/^SESSION_SECRET=.*$/m, 'SESSION_SECRET=' + secret)
    : content + '\nSESSION_SECRET=' + secret + '\n';
  fs.writeFileSync(ENV_PATH, content);
}

// 3) Dependências (instala o que estiver faltando, mesmo com node_modules incompleto)
require('./instalar-dependencias');

// 4) Porta (lê do .env, padrão 3000)
const envText = fs.readFileSync(ENV_PATH, 'utf8');
const portMatch = envText.match(/^PORT=(\d+)/m);
const port = portMatch ? portMatch[1] : '3000';
const url = `http://localhost:${port}`;

passo(`Subindo o servidor em ${url}  (Ctrl+C para parar)\n`);
const server = spawn(process.execPath, ['server.js'], { cwd: SERVER_DIR, stdio: 'inherit' });
server.on('exit', (code) => process.exit(code || 0));
process.on('SIGINT', () => server.kill('SIGINT'));

// Abre o navegador depois de um instante (dá tempo do servidor subir)
if (!process.argv.includes('--sem-navegador')) {
  setTimeout(() => {
    const [cmd, args] = isWindows
      ? ['cmd', ['/c', 'start', '', url]]
      : process.platform === 'darwin' ? ['open', [url]] : ['xdg-open', [url]];
    try { spawn(cmd, args, { stdio: 'ignore', detached: true }).on('error', () => {}).unref(); } catch (e) {}
  }, 1500);
}
