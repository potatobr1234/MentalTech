#!/usr/bin/env node
// Aprova (ou lista/rejeita) contas de psicólogos direto no banco, sem
// precisar subir o servidor nem usar npm — só Node.
//
// Uso (rodar de dentro da pasta server/):
//
//   node scripts/approve-professional.js                → lista os pendentes
//   node scripts/approve-professional.js listar          → lista os pendentes
//   node scripts/approve-professional.js listar todos    → lista TODOS os profissionais
//   node scripts/approve-professional.js aprovar <email ou CRP>
//   node scripts/approve-professional.js rejeitar <email ou CRP>
//
// Exemplos:
//   node scripts/approve-professional.js aprovar ana@email.com
//   node scripts/approve-professional.js aprovar SP/12345

const db = require('../db/database');

const [, , command = 'listar', arg] = process.argv;

function findProfessional(identifier) {
  const normalized = identifier.trim();
  return db
    .prepare(
      `SELECT * FROM professionals WHERE email = ? COLLATE NOCASE OR crp_number = ? COLLATE NOCASE`
    )
    .get(normalized, normalized.toUpperCase());
}

function printRow(p) {
  console.log(
    `  #${p.id}  ${p.full_name}  <${p.email}>  CRP ${p.crp_number}  — ${p.verification_status}`
  );
}

function listPending() {
  const rows = db
    .prepare(`SELECT * FROM professionals WHERE verification_status = 'pending' ORDER BY created_at`)
    .all();
  if (rows.length === 0) {
    console.log('Nenhum cadastro profissional pendente. ✅');
    return;
  }
  console.log(`${rows.length} cadastro(s) pendente(s):\n`);
  rows.forEach(printRow);
  console.log('\nPara aprovar: node scripts/approve-professional.js aprovar <email ou CRP>');
}

function listAll() {
  const rows = db.prepare(`SELECT * FROM professionals ORDER BY created_at`).all();
  if (rows.length === 0) {
    console.log('Nenhum profissional cadastrado ainda.');
    return;
  }
  console.log(`${rows.length} profissional(is) no total:\n`);
  rows.forEach(printRow);
}

function setStatus(identifier, status, label) {
  if (!identifier) {
    console.error(`Informe o e-mail ou o CRP do profissional. Ex: node scripts/approve-professional.js ${status === 'approved' ? 'aprovar' : 'rejeitar'} ana@email.com`);
    process.exitCode = 1;
    return;
  }
  const professional = findProfessional(identifier);
  if (!professional) {
    console.error(`Nenhum profissional encontrado com e-mail/CRP "${identifier}".`);
    process.exitCode = 1;
    return;
  }
  db.prepare(`UPDATE professionals SET verification_status = ? WHERE id = ?`).run(status, professional.id);
  console.log(`${label}: ${professional.full_name} <${professional.email}> (CRP ${professional.crp_number})`);
}

switch (command) {
  case 'listar':
  case 'list':
    if (arg === 'todos' || arg === 'all') listAll();
    else listPending();
    break;

  case 'aprovar':
  case 'approve':
    setStatus(arg, 'approved', '✅ Aprovado');
    break;

  case 'rejeitar':
  case 'reject':
    setStatus(arg, 'rejected', '🚫 Rejeitado');
    break;

  default:
    console.log('Comando não reconhecido: ' + command);
    console.log('Uso: node scripts/approve-professional.js [listar|aprovar|rejeitar] [email ou CRP]');
    process.exitCode = 1;
}
