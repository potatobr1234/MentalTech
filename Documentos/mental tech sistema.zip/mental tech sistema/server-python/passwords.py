# -*- coding: utf-8 -*-
"""
Hash de senha sem nenhuma dependência externa (equivalente ao bcrypt da
versão Node, mas usando só `hashlib`/`hmac`/`secrets` da biblioteca padrão).

Usamos PBKDF2-HMAC-SHA256 com 200 000 iterações e um salt aleatório por
senha — é o mesmo algoritmo que o Django usa por padrão.
"""

import hashlib
import hmac
import secrets

ITERATIONS = 200_000
ALGORITHM = "sha256"


def hash_password(password: str) -> str:
    salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac(ALGORITHM, password.encode("utf-8"), bytes.fromhex(salt), ITERATIONS)
    return f"{salt}:{digest.hex()}"


def verify_password(password: str, stored_hash: str) -> bool:
    try:
        salt, digest_hex = stored_hash.split(":", 1)
    except ValueError:
        return False
    expected = hashlib.pbkdf2_hmac(ALGORITHM, password.encode("utf-8"), bytes.fromhex(salt), ITERATIONS)
    return hmac.compare_digest(expected.hex(), digest_hex)
