# Mental Tech — login e cadastro sem `npm` (Python puro)

Esta é uma segunda implementação do mesmo sistema de login/cadastro,
**sem nenhuma dependência para instalar** — nem `npm install`, nem sequer
`pip install`. Usa só a biblioteca padrão do Python 3 (`http.server`,
`sqlite3`, `hashlib`, `secrets`...), que já vem junto com o interpretador.

Funcionalmente é equivalente à versão em `../server` (Node/Express): mesmas
rotas, mesmas validações, mesmas tabelas SQL — só a tecnologia por baixo que
muda.

## Como rodar

Só precisa ter Python 3.8+ instalado (`python3 --version` para conferir).

```bash
cd server-python
python3 server.py
```

Pronto — nada para instalar. O servidor sobe em `http://localhost:3000` e já
serve o site inteiro (pasta `../Mental tech html`), então acesse tudo por lá.

Para mudar a porta: `PORT=8080 python3 server.py`.

## O que foi implementado

- Banco **SQLite** (`db.py` + `schema.sql`) com três tabelas:
  - `users` — contas de jovens (`cadastro.html` / `login.html`)
  - `professionals` — contas de psicólogos, com `verification_status` (`pending` / `approved` / `rejected`)
  - `sessions` — sessões de login (substitui o `express-session` da versão Node, já que aqui não há nenhuma lib de sessão)
- Hash de senha com **PBKDF2-HMAC-SHA256** (200 000 iterações + salt aleatório por senha) via `hashlib`/`secrets` — sem bcrypt, mas com a mesma ideia de segurança (nunca se grava a senha em texto puro).
- Sessão via cookie **httpOnly** (`Set-Cookie` manual, sem framework).
- Mesmas validações da versão Node (`validators.py`): e-mail válido/único, senha ≥ 8 caracteres e confirmada, termos aceitos, idade mínima 18 anos, CRP no formato `UF/00000`, especialidade dentro da lista permitida.
- Mesmas rotas:

| Método | Rota                                | Usado por                     |
|--------|--------------------------------------|--------------------------------|
| POST   | `/api/auth/register`                | `cadastro.html`               |
| POST   | `/api/auth/login`                   | `login.html`                  |
| POST   | `/api/auth/professional/register`   | `cadastro-profissional.html`  |
| POST   | `/api/auth/professional/login`      | `login-profissional.html`     |
| GET    | `/api/auth/logout`                  | links "Sair" do painel logado |
| GET    | `/api/auth/me`                      | checagem de sessão            |

Como os formulários HTML já apontam para essas mesmas rotas, **os dois
backends (Node e Python) são intercambiáveis** — suba qualquer um dos dois e
o front-end funciona sem alterações.

## Teste rápido (sem abrir o navegador)

```bash
# cria uma conta
curl -X POST http://localhost:3000/api/auth/register \
  -d "full_name=Kelvin Mendes&email=kelvin@example.com&birth_date=2000-05-10&password=senha1234&password_confirm=senha1234&terms_accepted=on"

# loga e guarda o cookie de sessão
curl -c cookies.txt -X POST http://localhost:3000/api/auth/login \
  -d "email=kelvin@example.com&password=senha1234"

# confirma que a sessão está ativa
curl -b cookies.txt http://localhost:3000/api/auth/me
```

## Aprovar um profissional manualmente

Sem lib nenhuma instalada, aprove um cadastro profissional direto pelo
próprio Python:

```bash
python3 -c "
import sqlite3
conn = sqlite3.connect('mental_tech.sqlite3')
conn.execute(\"UPDATE professionals SET verification_status='approved' WHERE email='profissional@email.com'\")
conn.commit()
"
```

## Diferenças em relação à versão Node

- Usa `ThreadingHTTPServer` (embutido) em vez do Express — atende várias requisições ao mesmo tempo, mas é um servidor bem mais simples (sem roteamento avançado, middlewares etc.). Para o escopo de login/cadastro é suficiente.
- Sessões ficam salvas na tabela `sessions` do próprio SQLite (a versão Node usa `better-sqlite3-session-store`, mas o princípio é o mesmo: sobrevive a reinícios do servidor).
- Hash de senha é PBKDF2 (stdlib) em vez de bcrypt (lib externa) — ambos são adequados para senhas, PBKDF2 só exige mais iterações para compensar não ter salt embutido como o bcrypt.

## Estrutura

```
server-python/
├── server.py       # servidor HTTP (rotas + sessão + serve o site estático)
├── db.py           # conexão SQLite + aplica schema.sql automaticamente
├── schema.sql       # tabelas users / professionals / sessions
├── passwords.py     # hash/verificação de senha (PBKDF2, só stdlib)
└── validators.py    # validações de e-mail, senha, CRP, idade mínima etc.
```
