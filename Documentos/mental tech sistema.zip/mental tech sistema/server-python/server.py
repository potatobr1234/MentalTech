# -*- coding: utf-8 -*-
"""
Mental Tech — sistema de login e cadastro sem nenhuma dependência externa.

Só usa a biblioteca padrão do Python (http.server, sqlite3, hashlib...),
então não precisa de `pip install` nem `npm install` — só rodar:

    python3 server.py

Implementa exatamente as mesmas rotas da versão Node (pasta ../server):
    POST /api/auth/register
    POST /api/auth/login
    POST /api/auth/professional/register
    POST /api/auth/professional/login
    GET  /api/auth/logout
    GET  /api/auth/me

E serve o site estático (pasta "../Mental tech html") em cima do mesmo
servidor, então dá pra acessar tudo em http://localhost:3000.
"""

import json
import mimetypes
import os
import secrets
import urllib.parse
from datetime import datetime, timedelta, timezone
from http import cookies
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from db import get_connection, init_db
from passwords import hash_password, verify_password
from validators import (
    validate_login,
    validate_register_professional,
    validate_register_user,
)

PORT = int(os.environ.get("PORT", 3000))
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIR = os.path.abspath(os.path.join(BASE_DIR, "..", "Mental tech html"))
SESSION_COOKIE_NAME = "mt_sid"
SESSION_LIFETIME_DAYS = 7

# Páginas que só podem ser acessadas por um usuário (tipo "user"/jovem)
# autenticado. Também usada para validar o campo "redirect" no login,
# evitando open redirect (só aceitamos alvos desta lista).
PROTECTED_PAGES = {
    "/psicologos.html",
    "/perfil-psicologo.html",
    "/agendar-consulta.html",
    "/agendamento-confirmado.html",
    "/dashboard.html",
    "/agenda.html",
    "/configuracoes.html",
}


# ---------------------------------------------------------------------------
# Sessões (equivalente ao express-session da versão Node, guardado em SQLite)
# ---------------------------------------------------------------------------

def create_session(account_type, account_id):
    token = secrets.token_hex(32)
    expires_at = (datetime.now(timezone.utc) + timedelta(days=SESSION_LIFETIME_DAYS)).isoformat()
    conn = get_connection()
    try:
        conn.execute(
            "INSERT INTO sessions (token, account_type, account_id, expires_at) VALUES (?, ?, ?, ?)",
            (token, account_type, account_id, expires_at),
        )
        conn.commit()
    finally:
        conn.close()
    return token


def get_session_account(token):
    if not token:
        return None
    conn = get_connection()
    try:
        row = conn.execute(
            "SELECT * FROM sessions WHERE token = ? AND expires_at > ?",
            (token, datetime.now(timezone.utc).isoformat()),
        ).fetchone()
        if not row:
            return None

        if row["account_type"] == "user":
            account = conn.execute("SELECT * FROM users WHERE id = ?", (row["account_id"],)).fetchone()
            if not account:
                return None
            return {
                "type": "user",
                "id": account["id"],
                "full_name": account["full_name"],
                "email": account["email"],
            }

        account = conn.execute("SELECT * FROM professionals WHERE id = ?", (row["account_id"],)).fetchone()
        if not account:
            return None
        return {
            "type": "professional",
            "id": account["id"],
            "full_name": account["full_name"],
            "email": account["email"],
            "specialty": account["specialty"],
        }
    finally:
        conn.close()


def destroy_session(token):
    if not token:
        return
    conn = get_connection()
    try:
        conn.execute("DELETE FROM sessions WHERE token = ?", (token,))
        conn.commit()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Handler HTTP
# ---------------------------------------------------------------------------

class Handler(BaseHTTPRequestHandler):
    server_version = "MentalTechAuth/1.0"

    # Deixa o log de acesso mais legível (host, data, requisição, status)
    def log_message(self, fmt, *args):
        print(f"{self.address_string()} - {fmt % args}")

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _get_cookie(self, name):
        header = self.headers.get("Cookie")
        if not header:
            return None
        jar = cookies.SimpleCookie()
        jar.load(header)
        morsel = jar.get(name)
        return morsel.value if morsel else None

    def _wants_json(self):
        accept = self.headers.get("Accept", "")
        return "application/json" in accept

    def _read_form_body(self):
        length = int(self.headers.get("Content-Length", 0) or 0)
        raw = self.rfile.read(length) if length else b""
        content_type = self.headers.get("Content-Type", "")

        if "application/json" in content_type:
            try:
                data = json.loads(raw.decode("utf-8") or "{}")
            except json.JSONDecodeError:
                data = {}
            # Normaliza para strings simples, como um form comum
            return {k: ("" if v is None else v) for k, v in data.items()}

        parsed = urllib.parse.parse_qs(raw.decode("utf-8"))
        return {k: v[0] for k, v in parsed.items()}

    def _send_json(self, status, payload):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _redirect(self, location, set_cookie=None, clear_cookie=False):
        self.send_response(302)
        self.send_header("Location", location)
        if set_cookie:
            self.send_header("Set-Cookie", set_cookie)
        if clear_cookie:
            self.send_header(
                "Set-Cookie",
                f"{SESSION_COOKIE_NAME}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0",
            )
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _session_cookie_header(self, token):
        max_age = SESSION_LIFETIME_DAYS * 24 * 60 * 60
        return f"{SESSION_COOKIE_NAME}={token}; Path=/; HttpOnly; SameSite=Lax; Max-Age={max_age}"

    def _require_login_or_redirect(self, path):
        """Retorna True se pode seguir servindo a página; caso contrário já
        envia o redirect para o login e retorna False."""
        token = self._get_cookie(SESSION_COOKIE_NAME)
        account = get_session_account(token)
        if account and account["type"] == "user":
            return True

        query = urllib.parse.urlencode({"error": "Faça login para continuar.", "redirect": path})
        self._redirect(f"/login.html?{query}")
        return False

    def _fail(self, redirect_to, message, status=400):
        if self._wants_json():
            self._send_json(status, {"ok": False, "error": message})
        else:
            query = urllib.parse.urlencode({"error": message})
            self._redirect(f"{redirect_to}?{query}")

    def _succeed(self, redirect_to, extra=None, set_cookie=None):
        if self._wants_json():
            payload = {"ok": True}
            if extra:
                payload.update(extra)
            body = json.dumps(payload).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            if set_cookie:
                self.send_header("Set-Cookie", set_cookie)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            self._redirect(redirect_to, set_cookie=set_cookie)

    # ------------------------------------------------------------------
    # Rotas de autenticação
    # ------------------------------------------------------------------

    def handle_register_user(self):
        form = self._read_form_body()
        error = validate_register_user(form)
        if error:
            return self._fail("/cadastro.html", error)

        email = form["email"].strip().lower()
        conn = get_connection()
        try:
            existing = conn.execute("SELECT id FROM users WHERE email = ?", (email,)).fetchone()
            if existing:
                return self._fail("/cadastro.html", "Já existe uma conta com este e-mail.")

            conn.execute(
                """
                INSERT INTO users (full_name, email, birth_date, password_hash, terms_accepted_at)
                VALUES (?, ?, ?, ?, datetime('now'))
                """,
                (
                    form["full_name"].strip(),
                    email,
                    form["birth_date"],
                    hash_password(form["password"]),
                ),
            )
            conn.commit()
        finally:
            conn.close()

        self._succeed("/login.html?registered=1")

    def handle_login_user(self):
        form = self._read_form_body()
        error = validate_login(form)
        if error:
            return self._fail("/login.html", error)

        email = form["email"].strip().lower()
        conn = get_connection()
        try:
            user = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
        finally:
            conn.close()

        if not user or not verify_password(form["password"], user["password_hash"]):
            return self._fail("/login.html", "E-mail ou senha inválidos.", status=401)

        token = create_session("user", user["id"])
        account = {"type": "user", "id": user["id"], "full_name": user["full_name"], "email": user["email"]}

        # Mesmo esquema de redirect pós-login da versão Node: só aceita
        # alvos da whitelist PROTECTED_PAGES para evitar open redirect.
        requested_redirect = form.get("redirect")
        target = requested_redirect if requested_redirect in PROTECTED_PAGES else "/dashboard.html"

        self._succeed(target, extra={"account": account}, set_cookie=self._session_cookie_header(token))

    def handle_register_professional(self):
        form = self._read_form_body()
        error = validate_register_professional(form)
        if error:
            return self._fail("/cadastro-profissional.html", error)

        email = form["email"].strip().lower()
        crp_number = form["crp_number"].strip().upper()

        conn = get_connection()
        try:
            if conn.execute("SELECT id FROM professionals WHERE email = ?", (email,)).fetchone():
                return self._fail("/cadastro-profissional.html", "Já existe uma conta com este e-mail.")
            if conn.execute("SELECT id FROM professionals WHERE crp_number = ?", (crp_number,)).fetchone():
                return self._fail("/cadastro-profissional.html", "Este CRP já está cadastrado.")

            # TODO (integração futura): validar o CRP junto ao Conselho Federal
            # de Psicologia antes de trocar verification_status para "approved".
            conn.execute(
                """
                INSERT INTO professionals (full_name, email, crp_number, specialty, password_hash, verification_status)
                VALUES (?, ?, ?, ?, ?, 'pending')
                """,
                (
                    form["full_name"].strip(),
                    email,
                    crp_number,
                    form["specialty"],
                    hash_password(form["password"]),
                ),
            )
            conn.commit()
        finally:
            conn.close()

        self._succeed("/login-profissional.html?pending=1")

    def handle_login_professional(self):
        form = self._read_form_body()
        error = validate_login(form)
        if error:
            return self._fail("/login-profissional.html", error)

        email = form["email"].strip().lower()
        conn = get_connection()
        try:
            professional = conn.execute("SELECT * FROM professionals WHERE email = ?", (email,)).fetchone()
        finally:
            conn.close()

        if not professional or not verify_password(form["password"], professional["password_hash"]):
            return self._fail("/login-profissional.html", "E-mail ou senha inválidos.", status=401)

        if professional["verification_status"] != "approved":
            return self._fail(
                "/login-profissional.html",
                "Seu CRP ainda está em análise. Avisaremos por e-mail assim que sua conta for aprovada.",
                status=403,
            )

        token = create_session("professional", professional["id"])
        account = {
            "type": "professional",
            "id": professional["id"],
            "full_name": professional["full_name"],
            "email": professional["email"],
            "specialty": professional["specialty"],
        }
        # TODO (produto): ainda não existe um painel dedicado ao profissional
        # no front-end; redirecionando para a Home por enquanto.
        self._succeed("/index.html", extra={"account": account}, set_cookie=self._session_cookie_header(token))

    def handle_logout(self):
        token = self._get_cookie(SESSION_COOKIE_NAME)
        destroy_session(token)
        self._redirect("/selecionar-perfil.html", clear_cookie=True)

    def handle_me(self):
        token = self._get_cookie(SESSION_COOKIE_NAME)
        account = get_session_account(token)
        if not account:
            return self._send_json(401, {"ok": False, "authenticated": False})
        self._send_json(200, {"ok": True, "authenticated": True, "account": account})

    # ------------------------------------------------------------------
    # Arquivos estáticos (o site em si)
    # ------------------------------------------------------------------

    def serve_static(self, url_path):
        if url_path == "/":
            url_path = "/index.html"

        # Normaliza e impede path traversal (ex: /../../etc/passwd)
        safe_path = os.path.normpath(url_path).lstrip("/")
        file_path = os.path.abspath(os.path.join(FRONTEND_DIR, safe_path))

        if not file_path.startswith(FRONTEND_DIR) or not os.path.isfile(file_path):
            # Sem rota/arquivo correspondente: cai para index.html (mesmo
            # comportamento simples da versão Node).
            file_path = os.path.join(FRONTEND_DIR, "index.html")

        content_type, _ = mimetypes.guess_type(file_path)
        content_type = content_type or "application/octet-stream"

        with open(file_path, "rb") as f:
            body = f.read()

        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    # ------------------------------------------------------------------
    # Roteamento
    # ------------------------------------------------------------------

    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        routes = {
            "/api/auth/register": self.handle_register_user,
            "/api/auth/login": self.handle_login_user,
            "/api/auth/professional/register": self.handle_register_professional,
            "/api/auth/professional/login": self.handle_login_professional,
        }
        handler = routes.get(path)
        if handler:
            return handler()
        self._send_json(404, {"ok": False, "error": "Rota não encontrada."})

    def do_GET(self):
        path = urllib.parse.urlparse(self.path).path
        if path == "/api/auth/logout":
            return self.handle_logout()
        if path == "/api/auth/me":
            return self.handle_me()
        if path in PROTECTED_PAGES and not self._require_login_or_redirect(path):
            return
        return self.serve_static(path)


def main():
    init_db()
    server = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    print(f"Mental Tech (versão sem npm) rodando em http://localhost:{PORT}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
