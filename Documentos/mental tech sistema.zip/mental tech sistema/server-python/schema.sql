-- Mental Tech — schema do sistema de login e cadastro (SQLite)
-- Executado automaticamente em server-python/db.py ao iniciar o servidor.
-- (Mesmas tabelas da versão Node — só foi adicionada "sessions" porque,
--  sem express-session, precisamos guardar a sessão de login em algum lugar.)

CREATE TABLE IF NOT EXISTS users (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  full_name         TEXT NOT NULL,
  email             TEXT NOT NULL UNIQUE COLLATE NOCASE,
  birth_date        TEXT NOT NULL,             -- YYYY-MM-DD
  password_hash     TEXT NOT NULL,             -- "salt_hex:hash_hex" (PBKDF2-SHA256)
  terms_accepted_at TEXT NOT NULL,
  created_at        TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

CREATE TABLE IF NOT EXISTS professionals (
  id                   INTEGER PRIMARY KEY AUTOINCREMENT,
  full_name            TEXT NOT NULL,
  email                TEXT NOT NULL UNIQUE COLLATE NOCASE,
  crp_number           TEXT NOT NULL UNIQUE COLLATE NOCASE,
  specialty            TEXT NOT NULL,
  password_hash        TEXT NOT NULL,
  verification_status  TEXT NOT NULL DEFAULT 'pending'
                        CHECK (verification_status IN ('pending', 'approved', 'rejected')),
  created_at           TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_professionals_email ON professionals(email);
CREATE INDEX IF NOT EXISTS idx_professionals_crp ON professionals(crp_number);

-- Sessões de login (substitui o "express-session" da versão Node).
CREATE TABLE IF NOT EXISTS sessions (
  token       TEXT PRIMARY KEY,
  account_type TEXT NOT NULL CHECK (account_type IN ('user', 'professional')),
  account_id  INTEGER NOT NULL,
  created_at  TEXT NOT NULL DEFAULT (datetime('now')),
  expires_at  TEXT NOT NULL
);
