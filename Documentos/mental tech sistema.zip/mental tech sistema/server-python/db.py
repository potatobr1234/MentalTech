# -*- coding: utf-8 -*-
"""
Conexão com o banco SQLite + criação automática das tabelas.

Só usa a biblioteca padrão do Python (módulo `sqlite3`), então não há
nada para instalar: `sqlite3` já vem embutido no interpretador.
"""

import os
import sqlite3

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("MT_DB_PATH", os.path.join(BASE_DIR, "mental_tech.sqlite3"))
SCHEMA_PATH = os.path.join(BASE_DIR, "schema.sql")


def get_connection():
    """Abre uma conexão nova (SQLite é seguro para isso; cada request usa a sua)."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    """Cria as tabelas caso ainda não existam. Chamado uma vez, ao subir o servidor."""
    with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
        schema = f.read()
    conn = get_connection()
    try:
        conn.executescript(schema)
        conn.commit()
    finally:
        conn.close()
