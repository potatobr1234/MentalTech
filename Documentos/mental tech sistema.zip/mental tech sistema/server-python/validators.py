# -*- coding: utf-8 -*-
"""
Validações usadas pelas rotas de cadastro/login — mesma regra da versão
Node (server/utils/validators.js), reescritas em Python puro.
"""

import re
from datetime import date

EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")
CRP_RE = re.compile(r"^[A-Za-z]{2}/\d{4,6}$")

ALLOWED_SPECIALTIES = {
    "clinica",
    "infantil",
    "cognitivo_comportamental",
    "familiar",
    "neuropsicologia",
    "organizacional",
}


def is_valid_email(email):
    return bool(email) and bool(EMAIL_RE.match(email.strip()))


def is_valid_crp(crp):
    return bool(crp) and bool(CRP_RE.match(crp.strip()))


def is_valid_specialty(specialty):
    return specialty in ALLOWED_SPECIALTIES


def is_old_enough(birth_date_str, min_age=18):
    try:
        year, month, day = (int(part) for part in birth_date_str.split("-"))
        birth_date = date(year, month, day)
    except (ValueError, AttributeError):
        return False

    today = date.today()
    age = today.year - birth_date.year - ((today.month, today.day) < (birth_date.month, birth_date.day))
    return age >= min_age


def validate_register_user(form):
    full_name = form.get("full_name", "").strip()
    email = form.get("email", "")
    birth_date = form.get("birth_date", "")
    password = form.get("password", "")
    password_confirm = form.get("password_confirm", "")
    terms_accepted = form.get("terms_accepted")

    if not full_name:
        return "Informe seu nome completo."
    if not is_valid_email(email):
        return "Informe um e-mail válido."
    if not birth_date:
        return "Informe sua data de nascimento."
    if not is_old_enough(birth_date, 18):
        return "É necessário ter 18 anos ou mais para se cadastrar."
    if not password or len(password) < 8:
        return "A senha deve ter no mínimo 8 caracteres."
    if password != password_confirm:
        return "As senhas não coincidem."
    if not terms_accepted:
        return "É necessário aceitar os termos de uso e a política de privacidade."
    return None


def validate_register_professional(form):
    full_name = form.get("full_name", "").strip()
    email = form.get("email", "")
    crp_number = form.get("crp_number", "")
    specialty = form.get("specialty", "")
    password = form.get("password", "")
    password_confirm = form.get("password_confirm", "")

    if not full_name:
        return "Informe seu nome completo."
    if not is_valid_email(email):
        return "Informe um e-mail profissional válido."
    if not is_valid_crp(crp_number):
        return "Informe o CRP no formato UF/00000 (ex: SP/12345)."
    if not is_valid_specialty(specialty):
        return "Selecione uma especialidade válida."
    if not password or len(password) < 8:
        return "A senha deve ter no mínimo 8 caracteres."
    if password != password_confirm:
        return "As senhas não coincidem."
    return None


def validate_login(form):
    email = form.get("email", "")
    password = form.get("password", "")
    if not is_valid_email(email) or not password:
        return "Informe e-mail e senha."
    return None
